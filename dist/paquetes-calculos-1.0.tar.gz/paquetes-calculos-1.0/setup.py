from setuptools import setup

setup(
    name="paquetes-calculos",
    version="1.0",
    description="Paquete de calculos avanzados redondeoyportencia",
    author="Anthony-snk",
    author_email="anthony69snk@gmail.com",
    url="www.example.com",
    packages=["paquetes","paquetes.avanzados"] #Primero el nombre del paquete-la carpeta, el subpaquete con ruta completa
)
