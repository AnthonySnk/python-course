
def potencia (base,exponente):
    print(f"El resultado es:",base**exponente)

def redondear (numero):
    print(f"El resultado es:",round(numero))